//Grupo 6: Jorge Veros Moreno y Álvaro Rocha del Barrio
package tp1.logic;

public interface GameModel {

	public boolean isFinished();
	public void update();
	public void reset(); 
	public void exit();
	public void resetLives();
	public void resetPoints();
	public boolean reset(int nLevel);
	public void clearList();
	public boolean addObject(String[] strsObject);
	public void addAction(Action action);
}
