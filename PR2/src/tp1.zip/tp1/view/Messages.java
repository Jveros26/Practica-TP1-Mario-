//Grupo 6: Jorge Veros Moreno y Álvaro Rocha del Barrio
package tp1.view;

import tp1.utils.MyStringUtils;

public class Messages {
	
	public static final String VERSION = "1.0";

	public static final String GAME_NAME = "MarioBross";

	public static final String USAGE = "Usage: %s [<level>]".formatted(GAME_NAME);

	public static final String WELCOME = String.format("%s %s%n", GAME_NAME, VERSION);

	public static final String LEVEL_NOT_A_NUMBER = "The level must be a number";
	public static final String INVALID_LEVEL_NUMBER = "Not valid level number";

	public static final String LEVEL_NOT_A_NUMBER_ERROR = String.format("%s: %%s", LEVEL_NOT_A_NUMBER);

	public static final String PROMPT = "Command > ";

	public static final String DEBUG = "[DEBUG] Executing: %s%n";
	public static final String ERROR = "[ERROR] Error: %s";

	// GAME STATUS
	public static final String NUMBER_OF_CYCLES = "Number of cycles: %s";

	public static final String REMAINING_TIME = "Time: %s";
	public static final String POINTS = "Points: %s";
	public static final String NUM_LIVES = "Lives: %s";

	// GAME END MESSAGE
	public static final String GAME_OVER = "Game over";
	public static final String PLAYER_QUITS = "Player leaves the game";
	public static final String MARIO_WINS = "Thanks, Mario! Your mission is complete.";
	// Position format
	public static final String POSITION = "(%s,%s)";

	// Other
	public static final String SPACE = " ";
	public static final String TAB = "   ";
	public static final String LINE_SEPARATOR = System.lineSeparator();
	public static final String LINE = "%s" + LINE_SEPARATOR;
	public static final String LINE_TAB = TAB + LINE;
	public static final String LINE_2TABS = TAB + LINE_TAB;

//Commands
	public static final String UNKNOWN_COMMAND = "Unknown command: %s";
	public static final String UNKNOWN_ACTION = "Unknown action: \"%s\"";
	public static final String ILLEGAL_ACTION = "Illegal action: \"%s\"";
	// Errores de commandos:
	public static final String COMMAND_PARAMETERS_MISSING = "Missing parameters";
	public static final String COMMAND_INCORRECT_PARAMETER_NUMBER = "Incorrect parameter number";
	public static final String INVALID_COMMAND = "Invalid command: %s";
	public static final String INVALID_COMMAND_PARAMETERS = "Invalid command parameters";
	public static final String ERROR_COMMAND_EXECUTE = "Command execute problem";
	public static final String ERROR_COMMAND_INVALIDGAMEOBJECT = "Invalid game object: <stringObjeto>";
	public static final String INVALID_GAME_LEVEL= "Not valid level number";
	public static final String INVALID_GAME_OBJECT="Invalid game object:%s";

	
	public static final String HELP_AVAILABLE_COMMANDS = "Available commands:";

	/* @formatter:off */
	public static final String[] HELP_LINES = new String[] { HELP_AVAILABLE_COMMANDS,
		"[a]ction [[R]IGHT | [L]EFT | [U]P | [D]OWN | [S]TOP]+: user performs actions",
		"[u]pdate | \"\": user does not perform any action",
		"[r]eset [numLevel]: reset the game to initial configuration if not numLevel else load the numLevel map",
		"[h]elp: print this help message",
		"[e]xit: exits the game"
	};
	/* @formatter:on */

	public static final String HELP = String.join(LINE_SEPARATOR+"   ", HELP_LINES) + LINE_SEPARATOR;
	public static final String COMMAND_HELP_TEXT = "%s: %s";
	
// UPDATE
	public static final String COMMAND_UPDATE_NAME = "update";
	public static final String COMMAND_UPDATE_SHORTCUT = "u";
	public static final String COMMAND_UPDATE_DETAILS = "[u]pdate | \"\"";
	public static final String COMMAND_UPDATE_HELP = "user does not perform any action";
			
// EXIT
	public static final String COMMAND_EXIT_NAME = "exit";
	public static final String COMMAND_EXIT_SHORTCUT = "e";
	public static final String COMMAND_EXIT_DETAILS = "[e]xit";
	public static final String COMMAND_EXIT_HELP = "exits the game";
// Reset
	public static final String COMMAND_RESET_NAME = "reset";
	public static final String COMMAND_RESET_SHORTCUT = "r";
	public static final String COMMAND_RESET_DETAILS = "[r]eset [numLevel]: reset the game to initial configuration if not numLevel else load the numLevel map";
	public static final String COMMAND_RESET_HELP = "resets the game";
// Action
	public static final String COMMAND_ACTION_NAME = "action";
	public static final String COMMAND_ACTION_SHORTCUT = "a";
	public static final String COMMAND_ACTION_DETAILS = "[a]ction";
	public static final String COMMAND_ACTION_HELP = "[[R]IGHT | [L]EFT | [U]P | [D]OWN | [S]TOP]+: user performs actions";
		
// HELP
	public static final String COMMAND_HELP_NAME = "help";
	public static final String COMMAND_HELP_SHORTCUT = "h";
	public static final String COMMAND_HELP_DETAILS = "[h]elp";
	public static final String COMMAND_HELP_HELP = "print this help message";
//AddObjectCommand
	public static final String COMMAND_AddAction_NAME = "addObject";
	public static final String COMMAND_AddAction_SHORTCUT = "aO";
	public static final String COMMAND_AddAction_DETAILS = "[a]dd[O]bject <object_description>";
	public static final String COMMAND_AddAction_HELP = "adds to the board the object given by object_description\n"
			+ "\t\t <object_description> = (col,row) objName [dir [BIG|SMALL]]. Ej. (12,3) Mario LEFT SMALL";	
//GAMEOBJECT
	public static final String MARIO_NAME = "MARIO";
	public static final String GOOMBA_NAME = "GOOMBA";
	public static final String EXITDOOR_NAME = "EXITDOOR";
	public static final String LAND_NAME = "LAND";
	public static final String MARIO_SHORTCUT = "M";
	public static final String GOOMBA_SHORTCUT = "G";
	public static final String EXITDOOR_SHORTCUT = "ED";
	public static final String LAND_SHORTCUT = "L";
	public static final String BIG_NAME = "BIG";
	public static final String BIG_SHORTCUT= "B";
	public static final String SMALL_NAME = "SMALL";
	public static final String SMALL_SHORTCUT = "S";
	public static final String MUSHROOM_SHORTCUT = "MU";
	public static final String MUSHROOM_NAME = "MUSHROOM";
	public static final String BOX_NAME="BOX";
	public static final String BOX_SHORTCUT="B";



//Symbols
	public static final String EMPTY = "";
	public static final String LAND = MyStringUtils.repeat("▓",ConsoleView.CELL_SIZE);
	public static final String EXIT_DOOR = "🚪";
	public static final String MARIO_STOP = "🧑";
	public static final String MARIO_RIGHT = "🧍";//"🧍➡️";
	public static final String MARIO_LEFT = "🚶";//"⬅️🚶";
	public static final String GOOMBA = "🐻";
	public static final String MUSHROOM = "🍄";
	public static final String OPENED_BOX="0";
	public static final String NOT_OPENED_BOX="?";

}
